This README file describes the dataset used in Aletras and Stevenson (IWCS, 2013).

The dataset consists of the following files:

  topics20NG.txt	100 topics generated from the 20 News Group Data Collection.
  topicsNYT.txt		100 topics generated from New York Times news articles 
  			from May 2010 -Dec 2010 included in GigaWord corpus.
  topicsGenomics.txt	100 topics generated from 30,000 scientific articles in MEDLINE.
  
  gold20NG.txt		Average response for each topic (1-3)
  goldNYT.txt		Average response for each topic (1-3)
  goldGenomics.txt	Average response for each topic (1-3)
  
  goldFull20NG.txt	Ratings given by each participant for each topic; 
  			each line contains the topic number, the name of the 
  			collection and ratings separated by space.
  goldFullNYT.txt	Ratings given by each participant for each topic; 
  			each line contains the topic number, the name of the 
  			collection and ratings separated by space.
  goldFullGenomics.txt	Ratings given by each participant for each topic; 
  			each line contains the topic number, the name of the 
  			collection and ratings separated by space.
  
  
If you use the data please cite:

Nikolaos Aletras and Mark Stevenson (2013). Evaluating Topic Coherence Using Distributional Semantics. In Proceedings of the 10th Tenth International Conference for Computational Semantics (IWCS). Potsdam, Germany.
